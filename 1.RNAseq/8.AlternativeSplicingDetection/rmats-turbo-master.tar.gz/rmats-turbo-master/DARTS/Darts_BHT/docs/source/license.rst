LICENSE
========

.. include:: ../../LICENSE
